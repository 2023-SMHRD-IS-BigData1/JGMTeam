package main;

import java.util.Scanner;

import member.SignIn;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		SignIn si = new SignIn();

		Stage title = new Stage();
		
		title.title();
		
		

		while (true) {
			System.out.print("[1]회원가입 [2]로그인 >> ");
			int input = sc.nextInt();

			if (input == 1) {
				si.signIn();
				

			} else if (input == 2) {
				si.login();
				break;

			} else {
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요.");
			}
		}
		
		
		
		
		
	}

}
