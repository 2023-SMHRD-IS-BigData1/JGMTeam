package main;

public class Stage {

	String a;

	public void title() {
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("         ██╗     ██╗ █████╗ ███╗   ██╗ ██████╗      ██████╗ ██╗   ██╗        ");
		System.out.println("         ██║     ██║██╔══██╗████╗  ██║██╔════╝     ██╔════╝ ██║   ██║        ");
		System.out.println("         ██║     ██║███████║██╔██╗ ██║██║  ███╗    ██║  ███╗██║   ██║        ");
		System.out.println("    ██   ██║██   ██║██╔══██║██║╚██╗██║██║   ██║    ██║   ██║██║   ██║        ");
		System.out.println("    ╚█████╔╝╚█████╔╝██║  ██║██║ ╚████║╚██████╔╝    ╚██████╔╝╚██████╔╝        ");
		System.out.println("     ╚════╝  ╚════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝      ╚═════╝  ╚═════╝         ");
		System.out.println("                                                                             ");
		System.out.println(" █████╗ ██████╗ ██╗   ██╗███████╗███╗   ██╗████████╗██╗   ██╗██████╗ ███████╗");
		System.out.println("██╔══██╗██╔══██╗██║   ██║██╔════╝████╗  ██║╚══██╔══╝██║   ██║██╔══██╗██╔════╝");
		System.out.println("███████║██║  ██║██║   ██║█████╗  ██╔██╗ ██║   ██║   ██║   ██║██████╔╝█████╗  ");
		System.out.println("██╔══██║██║  ██║╚██╗ ██╔╝██╔══╝  ██║╚██╗██║   ██║   ██║   ██║██╔══██╗██╔══╝  ");
		System.out.println("██║  ██║██████╔╝ ╚████╔╝ ███████╗██║ ╚████║   ██║   ╚██████╔╝██║  ██║███████╗");
		System.out.println("╚═╝  ╚═╝╚═════╝   ╚═══╝  ╚══════╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝");
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();

	}

}
