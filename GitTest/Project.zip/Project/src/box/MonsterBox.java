package box;

public class MonsterBox {

}
