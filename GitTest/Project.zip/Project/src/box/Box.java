package box;

public class Box {

}
