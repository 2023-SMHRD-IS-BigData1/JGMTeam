package box;

public class GageBox {

}
