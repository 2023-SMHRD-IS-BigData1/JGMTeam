package object;

public class Teacher {

}
