package object;

public class JJangGu {

}
