package object;

public class Buriburi {

}
