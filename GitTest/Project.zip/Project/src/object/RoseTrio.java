package object;

public class RoseTrio {

}
