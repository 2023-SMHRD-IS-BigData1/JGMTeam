package object;

public class Boss {

}
