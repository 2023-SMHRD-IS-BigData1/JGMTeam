package member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	MemberDTO dto = null;
	int cnt = 0;
	String data = "";

	public void getCon() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String db_id = "service";
			String db_pw = "12345";

			conn = DriverManager.getConnection(url, db_id, db_pw);
		} catch (ClassNotFoundException e) {
			System.out.println("동적로딩 실패!(OracleDriver 클래스를 못 찾았습니다)");
		} catch (SQLException e) {
			System.out.println("SQL 오류~");
		}
	}

	public void getClose() {

		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
		}

	}

	public int insert(MemberDTO dto) {

		getCon();

		try {
			String sql = "INSERT INTO SIGNIN VALUES(?, ?, ?)";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPw());
			psmt.setString(3, dto.getNicName());

			cnt = psmt.executeUpdate();

		} catch (SQLException e) {

		} finally {
			getClose();
		}
		return cnt;

	}

	public String login(MemberDTO dto) {

		try {

			getCon();

			String sql = "select* from signin where id = ? and pw = ? ";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, dto.getId()); 
			psmt.setString(2, dto.getPw());

			rs = psmt.executeQuery();

			if (rs.next()) {
				String name = rs.getString("NICKNAME");
				data += name;
				return data;

			}
		}  catch (SQLException e) {
			System.out.println("SQL오류!");
		} finally {
			
			getClose();

		}
		return data;

	}

}
