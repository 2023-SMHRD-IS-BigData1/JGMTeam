package member;

public class Controller {

	MemberDAO dao = new MemberDAO();

	public void insert(MemberDTO dto) {

		int cnt = dao.insert(dto);

		if (cnt > 0) {
			System.out.println("회원가입 성공");
		} else {
			System.out.println("회원가입 실패");
		}

	}

	public void login(MemberDTO dto) {

		String data = new MemberDAO().login(dto);

		if (data != "") {

			System.out.println(data + "님 환영합니다!");
		} else {
			System.out.println("로그인 실패ಥ_ಥ");

		}

	}

}
