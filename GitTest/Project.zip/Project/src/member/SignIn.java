package member;

import java.util.Scanner;






public class SignIn {

	String member;
	Scanner sc = new Scanner(System.in);
		Controller con = new Controller();
	
	public void signIn() {
		
		MemberDTO dto = new MemberDTO(null, null, null);
		System.out.print("ID : ");
		String id = sc.next();
		System.out.print("PW : ");
		String pw = sc.next();
		System.out.print("NICKNAME : ");
		String nickName = sc.next();
		
		dto = new MemberDTO(id, pw, nickName);
			con.insert(dto);
		
	}
	
	
	public void login() {
		
		
		System.out.print("ID : ");
		String id = sc.next();
		System.out.print("PW : ");
		String pw = sc.next();
		
		MemberDTO dto = new MemberDTO(id, pw);
		Controller con = new Controller();
		con.login(dto);
		
				
		
		
	}
	
}
